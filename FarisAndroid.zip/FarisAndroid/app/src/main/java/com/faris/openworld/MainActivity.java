package com.faris.openworld;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private WebView webView;
    private Thread serverThread;
    private volatile boolean running = true;
    private final Map<String, JSONObject> players = Collections.synchronizedMap(new HashMap<>());
    private ServerSocket serverSocket;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff10172b);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        startServer();
        webView.loadUrl("http://127.0.0.1:8080/");
        String ip = getWifiIp();
        Toast.makeText(this, "للانضمام من هاتف آخر افتح: http://" + ip + ":8080", Toast.LENGTH_LONG).show();
    }

    private String getWifiIp() {
        try {
            WifiManager wm = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            int ip = wm.getConnectionInfo().getIpAddress();
            return Formatter.formatIpAddress(ip);
        } catch(Exception e) { return "عنوان-الهاتف"; }
    }

    private void startServer() {
        serverThread = new Thread(() -> {
            try {
                serverSocket = new ServerSocket();
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress("0.0.0.0", 8080));
                while (running) {
                    Socket client = serverSocket.accept();
                    new Thread(() -> handle(client)).start();
                }
            } catch(Exception ignored) {}
        });
        serverThread.start();
    }

    private void handle(Socket socket) {
        try (Socket s = socket;
             BufferedInputStream in = new BufferedInputStream(s.getInputStream());
             OutputStream out = s.getOutputStream()) {
            s.setSoTimeout(3000);
            ByteArrayOutputStream headerBytes = new ByteArrayOutputStream();
            int prev=0, cur;
            while ((cur=in.read())!=-1) {
                headerBytes.write(cur);
                if(prev=='\r' && cur=='\n') {
                    byte[] a=headerBytes.toByteArray();
                    int n=a.length;
                    if(n>=4 && a[n-4]=='\r' && a[n-3]=='\n') break;
                }
                prev=cur;
                if(headerBytes.size()>16000) return;
            }
            String headers = headerBytes.toString(StandardCharsets.ISO_8859_1.name());
            String[] lines=headers.split("\r\n");
            if(lines.length==0) return;
            String[] first=lines[0].split(" ");
            String method=first.length>0?first[0]:"GET";
            String path=first.length>1?first[1]:"/";
            int contentLength=0;
            for(String line:lines) if(line.toLowerCase(Locale.ROOT).startsWith("content-length:")) {
                try { contentLength=Integer.parseInt(line.substring(line.indexOf(':')+1).trim()); } catch(Exception ignored){}
            }
            if(method.equals("POST") && path.equals("/state")) {
                byte[] body=new byte[Math.min(contentLength,20000)];
                int got=0; while(got<body.length){int r=in.read(body,got,body.length-got);if(r<0)break;got+=r;}
                try {
                    JSONObject p=new JSONObject(new String(body,0,got,StandardCharsets.UTF_8));
                    String id=p.optString("id","");
                    if(!id.isEmpty()) {p.put("t",System.currentTimeMillis());players.put(id,p);}
                } catch(Exception ignored){}
                respond(out,204,"text/plain","",false); return;
            }
            if(method.equals("GET") && path.startsWith("/state")) {
                long now=System.currentTimeMillis();
                synchronized(players){Iterator<Map.Entry<String,JSONObject>> it=players.entrySet().iterator();while(it.hasNext()){if(now-it.next().getValue().optLong("t",0)>8000)it.remove();}}
                JSONObject obj=new JSONObject(); JSONObject ps=new JSONObject();
                synchronized(players){for(Map.Entry<String,JSONObject> e:players.entrySet())try{ps.put(e.getKey(),e.getValue());}catch(Exception ignored){}}
                obj.put("players",ps);
                respond(out,200,"application/json; charset=utf-8",obj.toString(),true); return;
            }
            if(method.equals("GET")) {
                try(InputStream asset=getAssets().open("index.html")) {
                    byte[] data=readAll(asset);
                    respondBytes(out,200,"text/html; charset=utf-8",data,true);
                } catch(Exception e) { respond(out,404,"text/plain","Not found",true); }
                return;
            }
            respond(out,404,"text/plain","Not found",true);
        } catch(Exception ignored) {}
    }

    private byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
        while((n=in.read(buf))!=-1)b.write(buf,0,n); return b.toByteArray();
    }
    private void respond(OutputStream out,int code,String type,String body,boolean close) throws IOException {
        respondBytes(out,code,type,body.getBytes(StandardCharsets.UTF_8),close);
    }
    private void respondBytes(OutputStream out,int code,String type,byte[] body,boolean close) throws IOException {
        String label=code==200?"OK":code==204?"No Content":code==404?"Not Found":"OK";
        String h="HTTP/1.1 "+code+" "+label+"\r\nContent-Type: "+type+"\r\nContent-Length: "+body.length+"\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.ISO_8859_1)); if(body.length>0)out.write(body);out.flush();
    }

    @Override public void onDestroy() {
        running=false;
        try { if(serverSocket!=null) serverSocket.close(); } catch(Exception ignored){}
        if(webView!=null) webView.destroy();
        super.onDestroy();
    }
}
